package com.konyol.babycarex.data.model

data class Kategori(
    val id: Int? = null,
    val kategori: String,
    val created_at: String? = null,
    val updated_at: String? = null
)
